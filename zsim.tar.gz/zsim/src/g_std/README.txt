This folder simply has template spacializations of STL classes that use the
global heap allocator. Feel free to define new specializations as needed.

See g_vector.h for a brief discussion/pointers on how to do this. This should
be more elegant when/if template typedefs get in C++2011.
