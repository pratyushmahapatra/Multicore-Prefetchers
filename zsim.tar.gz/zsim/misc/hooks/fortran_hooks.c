#include "zsim_hooks.h"

void zsim_roi_begin_() {
    zsim_roi_begin();
}

void zsim_roi_end_() {
    zsim_roi_end();
}

void zsim_heartbeat_() {
    zsim_heartbeat();
}

